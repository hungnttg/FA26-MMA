import React from "react";
import { Text, View, Image, TouchableWithoutFeedback, StyleSheet } from "react-native";

const ProductFn = ({ dataProd, handlePress }) => {
    if (!dataProd) return null;

    const imgUri = dataProd.search_image?.replace(/^http:\/\//i, "https://");

    return (
        <TouchableWithoutFeedback onPress={() => handlePress && handlePress(dataProd)}>
            <View style={styles.card}>
                <Image source={{ uri: imgUri }} style={styles.image} />
                <Text style={styles.brand}>{dataProd.brands_filter_facet}</Text>
                <Text numberOfLines={2} style={styles.name}>{dataProd.product_additional_info}</Text>
                <Text style={styles.price}>{dataProd.price} VND</Text>
            </View>
        </TouchableWithoutFeedback>
    );
};

export default ProductFn;

const styles = StyleSheet.create({
    card: { flex: 1, margin: 5, padding: 8, borderWidth: 1, borderColor: "#ddd", borderRadius: 8, backgroundColor: "#fff", alignItems: "center" },
    image: { width: 120, height: 120, resizeMode: "contain" },
    brand: { fontWeight: "bold", color: "#ff5722", marginTop: 4 },
    name: { fontSize: 12, textAlign: "center", marginVertical: 2 },
    price: { fontWeight: "bold", color: "red" },
});