import React, { useState } from "react";
import { View, Button, FlatList, Text } from "react-native";
import { useLocalSearchParams } from "expo-router";
import ProductFn from "./Slot6_1_Model";

global.myCart = [];

const CartFn = () => {
    const [count, setCount] = useState(1);
    const [list, setList] = useState(global.myCart);
    const { data } = useLocalSearchParams();
    const itemData = data ? JSON.parse(data) : null;

    const allProductCart = () => {
        if (itemData) {
            global.myCart = [{ ...itemData, quantity: count }, ...global.myCart];
            setList([...global.myCart]);
        }
    };

    return (
        <View style={{ flex: 1, padding: 10 }}>
            {itemData && (
                <View style={{ marginBottom: 10, alignItems: "center" }}>
                    <ProductFn dataProd={itemData} />
                    <View style={{ flexDirection: "row", alignItems: "center", marginVertical: 10 }}>
                        <Button title=" - " onPress={() => setCount(count > 1 ? count - 1 : 1)} />
                        <Text style={{ marginHorizontal: 15, fontSize: 16 }}>Số lượng: {count}</Text>
                        <Button title=" + " onPress={() => setCount(count + 1)} />
                    </View>
                    <Button title="Thêm vào giỏ hàng" onPress={allProductCart} />
                </View>
            )}

            <Text style={{ fontWeight: "bold", fontSize: 16, marginVertical: 10 }}>
                Danh sách giỏ hàng ({list.length}):
            </Text>

            <FlatList
                data={list}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item }) => <ProductFn dataProd={item} />}
                numColumns={2}
            />
        </View>
    );
};

export default CartFn;