import React from "react";
import { ScrollView, Button, View } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import ProductFn from "./Slot6_1_Model";

const DetailFn = () => {
    const router = useRouter();
    const { data } = useLocalSearchParams();
    const data1 = data ? JSON.parse(data) : {};

    const addToCart = () => {
        router.push({
            pathname: "/slot6/Slot6_4_Cart",
            params: { data: JSON.stringify(data1) },
        });
    };

    return (
        <ScrollView contentContainerStyle={{ padding: 10, alignItems: "center" }}>
            <ProductFn dataProd={data1} />
            <View style={{ marginTop: 10, width: "100%" }}>
                <Button title="Add to Cart" onPress={addToCart} />
            </View>
        </ScrollView>
    );
};

export default DetailFn;