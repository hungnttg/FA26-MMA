import React, { useState, useEffect } from "react";
import { FlatList } from "react-native";
import { useRouter } from "expo-router";
import ProductFn from "./Slot6_1_Model";

const ListProductFn = () => {
    const router = useRouter();
    const [prd, setPrd] = useState([]);

    const getProducts = async () => {
        const res = await fetch("https://hungnttg.github.io/shopgiay.json");
        const resJSON = await res.json();
        setPrd(resJSON.products);
    };

    useEffect(() => {
        getProducts();
    }, []);

    const viewDetail = (p) => {
        router.push({
            pathname: "/slot6/SLot6_3_Detail",
            params: { data: JSON.stringify(p) },
        });
    };

    return (
        <FlatList
            data={prd}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
                <ProductFn dataProd={item} handlePress={() => viewDetail(item)} />
            )}
            numColumns={2}
        />
    );
};

export default ListProductFn;