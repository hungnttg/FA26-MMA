import React from "react";
import { Stack } from "expo-router";

const NavFn = () => {
    return (
        <Stack initialRouteName="SLot6_2_ListProduct">
            <Stack.Screen name="SLot6_2_ListProduct" options={{ title: "Products" }} />
            <Stack.Screen name="SLot6_3_Detail" options={{ title: "Detail" }} />
            <Stack.Screen name="Slot6_4_Cart" options={{ title: "Cart" }} />
        </Stack>
    );
};

export default NavFn;