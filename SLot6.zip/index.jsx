import { Redirect } from 'expo-router';
import { View } from 'react-native';
// import Slot1_2 from './slot1/Slot1_2';
// import Slot2_3Cha from './slot2/Slot2_3Cha'; //import component
// import Slot5_2 from './slot5/SLot5_2';
 import NavFn from './slot6/SLot6_5';


export default function HomeScreen() {
   return <Redirect href="/slot6/SLot6_2_ListProduct" />;
  // return(
    // <NavFn/>
  // );
}
