import React from "react";
import { View,Text,Image,StyleSheet } from "react-native";
const SectionView = ({title,imageSource, description}) =>{
    return(
        <View style={styles.container}>
            <Text style={styles.title}>{title}</Text>
            <Image source={imageSource} style={styles.image}/>
            <Text style={styles.description}>{description}</Text>
        </View>
    );
};
const Slot9_2 = () =>{
    return(
        <View style={styles.container}>
            <SectionView title="Welcome"
            imageSource={{uri:'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=400'}}
            description="This is a welcome message"/>
        </View>
    );
};
export default Slot9_2;

const styles = StyleSheet.create({
    container:{
        padding:20,
        backgroundColor: '#ffffff',
        borderRadius:10,
        shadowColor: '#000',
        shadowOffset: {width:0,height:2},
        shadowOpacity:0.25,
        shadowRadius:3,
        elevation:5
    },
    title: {
        fontSize:25,
        fontWeight:'bold',
        marginBottom:10,
    },
    image: {
        width:'25%',
        height:200,
        marginBottom:10,
        borderRadius:5
    },
    description:{
        fontSize: 16,
    },
});