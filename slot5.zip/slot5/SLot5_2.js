//import thu vien
import React from "react";
import { FlatList } from "react-native";
import Product from "./Slot5_1";
export default class ListProduct extends React.Component{
    //1. khai bao bien, state trong constructor
    constructor(props){
        super(props);
        this.state={
            products: null,//khoi tao state ban dau
        };
        //khoi tao cac ham
        this.getProducts = this.getProducts.bind(this);//ham doc du lieu tu API
        this.renderItem = this.renderItem.bind(this);//ham render du lieu
    }
    //2. dinh nghia cac ham
    //2.1 ham doc du lieu
    async getProducts(){
        const url='https://hungnttg.github.io/shopgiay.json';
        let response = await fetch(url,{method:'GET'});//doc du lieu
        let resonseJSON = await response.json();//chuyen sang json
        this.setState({
            products: resonseJSON.products, //cap nhat ket qua doc duoc vao state
        });
    }
    componentDidMount(){//ham co san, duoc goi thi mount component
        this.getProducts();
    }
    //2.2 tao view
    renderItem({item}){
        return(
            <Product dataProd={item}/>
        );
    }
    //3. hien thi du lieu
    render(){
        return(
            <FlatList
                data={this.state.products}
                renderItem={this.renderItem}
                numColumns={3}
                removeClippedSubviews
            />
        );
    }
}