import React,{useState} from "react";
import { View,StyleSheet } from "react-native";
import Header from "./Header";
import Footer from "./Footer";
import Body from "./Body";
const Main = () =>{
    const [footerInfo,setFooterInfo]=useState('');
    const handleSubmit = (inputValue) =>{
        setFooterInfo(inputValue);
    };
    return(
        <View style={styles.container}>
            <Header/>
            <Body onSubmit={handleSubmit}/>
            <Footer info={footerInfo}/>
        </View>
    );
}
export default Main;
const styles = StyleSheet.create({
    container: {
        flex:1,
    },
});