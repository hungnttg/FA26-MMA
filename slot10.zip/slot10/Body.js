import React,{useState} from "react";
import { View,TextInput,Button,StyleSheet } from "react-native";
const Body = ({onSubmit}) =>{
    const [inputValue,setInputValue]=useState('');
    const handleSubmit = () =>{
        onSubmit(inputValue);
        setInputValue('');
    };
    return(
        <View style={styles.body}>
            <TextInput
                style={styles.input}
                placeholder="nhap gia tri..."
                value={inputValue}
                onChangeText={setInputValue}
            />
            <Button title="Submit" onPress={handleSubmit}/>
        </View>
    );

}
export default Body;
const styles = StyleSheet.create({
    body: {padding:20,},
    input: {
        height:40,
        borderColor: 'gray',
        borderWidth:1,
        marginBottom:10,
        paddingLeft:10
    }
});