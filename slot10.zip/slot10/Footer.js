import React from "react";
import { Text,View,StyleSheet } from "react-native";
const Footer = ({info}) =>{
    return(
        <View style={styles.footer}>
            <Text style={styles.footerText}>{info}</Text>
        </View>
    );
}
export default Footer;
const styles = StyleSheet.create({
    footer:{
        backgroundColor:'#f8f8fa',
        padding:10,
    },
    footerText:{
        fontSize:16,
        textAlign:'center',
    }
});