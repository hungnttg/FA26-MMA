import React from 'react';
import {Text,View,StyleSheet} from 'react-native';
const Header = () =>{
    return(
        <View style={styles.header}>
            <Text style={styles.headerText}>Header Component</Text>
        </View>
    );
};
export default Header;
const styles = StyleSheet.create({
    header: {
        backgroundColor:'#f8f8fa',
        padding:10,
    },
    headerText:{
        fontSize:20,
        fontWeight:'bold',
    },
});