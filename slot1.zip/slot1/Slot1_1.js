//1. Import thu vien
import React from "react";
import { Text, View } from "react-native";
//2/ Dinh nghia class
export default class Slot1_1 extends React.Component{
    render(){
        return(
            <View>
                <Text>Day la ung dung class</Text>
            </View>
        );
    }
}