import { Text, View } from "react-native";
const Slot1_2 = () =>{
    return(
        <View>
            <Text>Day la cachs su dung Function</Text>
        </View>
    );
}
export default Slot1_2;