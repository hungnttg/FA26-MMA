import { createReducer } from "@reduxjs/toolkit";
import { addItem,removeItem } from "./actions";
const initialState = {items: []};
const cartReducer = createReducer(initialState,builder => {
    builder
    .addCase(addItem,(state,action)=>{
        //lay id cua san pham muoon them
        const existingItemIndex = state.items.findIndex(
            item => item.id === action.payload.id
        );
    if(existingItemIndex !== -1){ //neu da ton tai Id
        state.items[existingItemIndex].quantity++;//them so luong
    }
    else {//neu chua co san pham trong gio nang
        state.items.push({...action.payload,quantity:1});//set so luong la 1
    }
    })
    .addCase(removeItem,(state,action)=>{
        //lay ve id
        //lay id cua san pham muoon them
        const existingItemIndex = state.items.findIndex(
            item => item.id === action.payload.id
        );
        if(existingItemIndex !== -1){
            state.items[existingItemIndex].quantity--;//giam so luong san pham
            if(state.items[existingItemIndex].quantity === 0){//neu so luong sp=0
                state.items.splice(existingItemIndex,1);//xoa san pham
            }
        }
    });
});
export default cartReducer;