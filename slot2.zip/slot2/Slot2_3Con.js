import React from "react";
import { View,Text } from "react-native";
export default function Slot2_3Con({name}){
    return(
        <View>
            <Text>Xin chao {name}</Text>
        </View>
    );
}