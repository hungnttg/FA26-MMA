import React,{useState} from "react";
import { Button } from "react-native";
import { View,Text } from "react-native";
export default function Slot2_2(){
    //khai bao state 'count' voi gia tri ban dau la 0
    const [count,setCount]=useState(0);
    //layout
    return(
        <View>
            <Text>So lan nhap: {count}</Text>
            <Button title="Click me" onPress={()=>setCount(count+1)} />
        </View>
    );
}