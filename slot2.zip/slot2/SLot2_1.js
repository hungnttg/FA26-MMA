import React from "react";
import { View,Text } from "react-native";
export default class Slot2_1 extends React.Component{
    //ham khoi tao
    constructor(props){
        super(props);
        this.state={
            //khai bao cac bien
            text: "click me",
            dem:0,
        };
    }
    //dinh nghia ham update khi click
    updateText(){
        this.setState((preState)=>{
            return {
                dem: preState.dem +1, //moi lan click se cong them 1
                text: "ban vua click lan "
            }
        });
    }
    //layout
    render(){
        return(
            <View>
                <Text onPress={()=>this.updateText()}>
                    {this.state.text} : {this.state.dem}
                </Text>
            </View>
        );
    }
}