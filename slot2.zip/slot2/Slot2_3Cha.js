import React from "react";
import Slot2_3Con from "./Slot2_3Con";
import { View,Text } from "react-native";
export default function Slot2_3Cha(){
    const userName = "Nguyen Van a";
    return(
        <View>
            {/* truyen du lieu tu cha sang con */}
            <Slot2_3Con name={userName}/>
        </View>
    );
}